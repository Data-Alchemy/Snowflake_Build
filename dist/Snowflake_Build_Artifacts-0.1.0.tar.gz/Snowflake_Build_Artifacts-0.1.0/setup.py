# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['snowflake_build_artifacts']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.5.1,<2.0.0',
 'pyarrow==6.0.0',
 'requests>=2.28.1,<3.0.0',
 'snowflake-connector-python>=2.8.0,<3.0.0']

setup_kwargs = {
    'name': 'snowflake-build-artifacts',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'sebastian hansen',
    'author_email': 'sebastian.hansen@dataalchemy.dev',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
